Custom Authorizers allow you to run an AWS Lambda Function via API Gateway before your targeted AWS Lambda Function is run. This is useful for Microservice Architectures or when you simply want to do some Authorization before running your business logic.


## Use cases

- Protect API routes for authorized users
- Rate limiting APIs
- Remotely revoke tokens

## Setup

1. `npm install` json web token dependencies

2. In [auth.js](auth.js#L10) replace the value of `iss` with either your [Auth0 iss](http://bit.ly/2hoeRXk) or [AWS Cognito ISS](http://amzn.to/2fo77UI). Make sure the `iss` url ends in a trailing `/`.

  ```js
  /* auth.js */
  // Replace with your Cognito values
  const iss = "https://<url>.com/";
  ```

3. Deploy the service with `sls deploy` and grab the public and private endpoints.

## Test Authentication:  
-  Test with [Postman](https://chrome.google.com/webstore/detail/postman/fhbjgbiflinjbdggehcddcbncdddomop?hl=en): Make a new GET request with the Header containing "Authorization" with the value being "bearer `<id_token>`" for your `api/private` url.
- Test using curl:
  ```sh
  curl --header "Authorization: bearer <id_token>" https://{api}.execute-api.{region}.amazonaws.com/api/private
  ```

https://ap-southeast-1.console.aws.amazon.com


https://gardabook.auth.ap-southeast-1.amazoncognito.com/login?response_type=token&client_id=1farfu2bjp9gdf746hjuvs0q0e&redirect_uri=https://gardabook.auth.ap-southeast-1.amazoncognito.com


Session: "f1TPyyKlT6q_A-ykKTezYS3GcpHsRPvinO_GOE4F0_dS2yRMIvxvfGOxFVjexRvA2TC_PD7tEcb6DMjLDTEwCwTMBTaFSYlK5d4CsrKCl5IVh3Por4zMwmGzL1zCmPew0FmlaQ5M2cshhFNbpLx6xust6yqQKPXUSN0SR0KghnSiIsMKAjTbLcxNh0hYDDnRXyh9G0cYHaBzGXGFmHSFHIuRyYTey5lsLTwvW7J9upp-cEPh21UmBl__toEGp3FHv8shK4lrLG7xwYbRAi7y5p8FnKeP5ICOsRsjwIvEW8tVoOQysLb8mOzh7bxYMcTC2Me5UacwEJC0rMzjxEubZxeNwqWkdtQwCV0BOLg4kJYhFrE6GmTQnsyHd9WlyZAZ0kX2mPPH01QgtPzohhKE-ivAV6qOGdNlC0aGLouaz4mCyVUAQGnEtcTLlmWGRvA35rI324bB9Tbs8uza3N1YMkHWsw6VKNc4SBp7cDNzK4xNeOfkjVzq2WXf-6naGZ1kpnrr-cIXKgw4-KpIhOI19FZtH3lFC_XsXqkUxRfUxoL_ckma3x8RZsHDVuQuLXVZsbxZVxi1foNhFAdhXw62aUbHYDJ5yuouw3-ii1gsUt12WMi77jp3Mrojc0m2h5TaLju6VCn6hG_3PhkHj9oQrjDedcmfQEWpf4ldGGGhvNS0IhB4xjo0jO_Hv0gxNi8prgFXy4g6IovECnLFLAa6cJnId-ziG9Br_voEuOZV0pH29RYWGAfBAbe_H5N8jVQ6X6kBtTbhOAoiqAIurUG56i9QH6T2mzVUJPpH0VUWZYTmLchUJ0wSvNuTXUtMAch6wGJXu1k_pcMGB6Izj-fAjjmI7-Ms85l1yLCleESz-ma8JqoGao3h6JknfbHYQLmr1RwRWhjqYVAjS2eDaEP_g01j3vpZWfDh-pVovX1H3AHY5pHMwgUY8iEwOMFcIH4JUdphrplKuY2VKj8U2P3t_qa0CO3WCAWibaUiSihJhSQkJlWvPsRPj33IeIPrVGOj7hk3_Yx81ww"